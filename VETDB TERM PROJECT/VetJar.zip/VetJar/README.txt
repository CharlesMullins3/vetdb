This program is configured to connect to localhost:3360 using -uroot -ptoor. Anything other connection will need to be inserted in the loginGUI initalization code.
